#include "lsadmin.h"

int main(int args, char* argv[]){

	ls_Admin(args, argv);
	return 0;
}
